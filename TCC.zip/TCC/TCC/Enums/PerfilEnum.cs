﻿namespace TCC.Enums
{
    public enum PerfilEnum
    {
        Admin = 0,
        Usuario = 1
    }
}
