﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TCC.Enums
{
    public enum StatusEventoEnum
    {
        FECHADO,
        ATIVO
    }
}
