﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TCC.Enums
{
    public enum StatusUsuarioEnum
    {
        ativo = 0,
        inativo = 1
    }
}
