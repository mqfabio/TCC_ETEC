﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TCC.Models
{
    public class UnidadeEnsino
    {
        public int CodUE { get; set; }
        public string Endereco { get; set; }
        public string Telefone { get; set; }
        //public blog Logotipo { get; set; }
    }
}
