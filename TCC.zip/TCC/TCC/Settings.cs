﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TCC
{
    public static class Settings
    {
        public static string Secret = "d41d8cd98f00b204e9800998ecf8427e";
    }
}
