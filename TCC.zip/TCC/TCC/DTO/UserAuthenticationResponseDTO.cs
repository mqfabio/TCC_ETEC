﻿namespace TCC.DTO
{
    public class UserAuthenticationResponseDTO
    {
        public string Nome { get; set; }
        public string Token { get; set; }

    }
}
